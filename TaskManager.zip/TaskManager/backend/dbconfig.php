<?php
$host = 'localhost';
$dbname = 'managementsystem';
$dbusername = 'root';
$dbpassword = '';
?>
